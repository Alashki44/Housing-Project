//------------element selectors

//by id

// document.querySelector("#box4")
// document.getElementById("box4")

//by class

// document.querySelector(".box")
// document.getElementsByClassName("box")

//select all

// document.querySelectorAll(".box")

//typeof
// console.log(typeof "hello")

//errors (console log let undefined....changing const, ...)

//---------functions

//old way

// function function_name(){
//     
// }


//new way

//() => {}

// ES5 Regular function

// let add = function(a, b) { return a + b;};
// console.log(add)

// ES6 Arrow function

// // let add = (a, b) => { return a + b }; 
// console.log(add)



//---- event listeners (on click, on change, on mouse enter, on mouse leave, )


// let box = document.getElementById("box4")
// console.log(box)
// box.onclick = change_background


// box.addEventListener("click", change_background)
// box.addEventListener("click", function(){box.style.backgroundColor = "red"})
// box.addEventListener("click", () => {box.style.backgroundColor = "red"})